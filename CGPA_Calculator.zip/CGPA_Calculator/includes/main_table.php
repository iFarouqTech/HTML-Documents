		<div class="container" id="container">
			<center>
				<table class="gridtable" id="tablemain">
					<!--form method="post" action="process.php"-->
						<thead>
							<th>S/N</th>
							<th>COURSE CODE</th>
							<th>COURSE UNIT</th>
							<th>COURSE grade</th>
						</thead>
						<tbody>
							<tr class="breakrow">
								<td>CLICK TO INSERT YOUR DATA</td><td></td><td></td><td></td>
							</tr>
							<tr class="datarow">
								<td class="sn">1</td>
								<td><input type="text" name="course_code_1" placeholder="Enter the course Code"></td>
								<td><input type="number" name="course_unit_1" placeholder="Enter the course unit"></td>
								<td><input type="text" name="course_grade_1" placeholder="Enter the course grade"></td>
							</tr>
							<tr class="datarow">
								<td class="sn">2</td>
								<td><input type="text" name="course_code_2" placeholder="Enter the course Code"></td>
								<td><input type="number" name="course_unit_2" placeholder="Enter the course unit"></td>
								<td><input type="text" name="course_grade_2" placeholder="Enter the course grade"></td>
							</tr>
							<tr class="datarow">
								<td class="sn">3</td>
								<td><input type="text" name="course_code_3" placeholder="Enter the course Code"></td>
								<td><input type="number" name="course_unit_3" placeholder="Enter the course unit"></td>
								<td><input type="text" name="course_grade_3" placeholder="Enter the course grade"></td>
							</tr>
							<tr class="datarow">
								<td class="sn">4</td>
								<td><input type="text" name="course_code_4" placeholder="Enter the course Code"></td>
								<td><input type="number" name="course_unit_4" placeholder="Enter the course unit"></td>
								<td><input type="text" name="course_grade_4" placeholder="Enter the course grade"></td>
							</tr>
							<tr class="datarow">
								<td class="sn">5</td>
								<td><input type="text" name="course_code_5" placeholder="Enter the course Code"></td>
								<td><input type="number" name="course_unit_5" placeholder="Enter the course unit"></td>
								<td><input type="text" name="course_grade_5" placeholder="Enter the course grade"></td>
							</tr>
							<tr class="breakrow">
								<td>CLICK ME TO LOAD INPUT</td><td></td><td></td><td></td>
							</tr>
							<tr class="datarow">
								<td class="sn">6</td>
								<td><input type="text" name="course_code_6" placeholder="Enter the course Code"></td>
								<td><input type="number" name="course_unit_6" placeholder="Enter the course unit"></td>
								<td><input type="text" name="course_grade_6" placeholder="Enter the course grade"></td>
							</tr>
							<tr class="datarow">
								<td class="sn">7</td>
								<td><input type="text" name="course_code_7" placeholder="Enter the course Code"></td>
								<td><input type="number" name="course_unit_7" placeholder="Enter the course unit"></td>
								<td><input type="text" name="course_grade_7" placeholder="Enter the course grade"></td>
							</tr>
							<tr class="datarow">
								<td class="sn">8</td>
								<td><input type="text" name="course_code_8" placeholder="Enter the course Code"></td>
								<td><input type="number" name="course_unit_8" placeholder="Enter the course unit"></td>
								<td><input type="text" name="course_grade_8" placeholder="Enter the course grade"></td>
							</tr>
							<tr class="datarow">
								<td class="sn">9</td>
								<td><input type="text" name="course_code_9" placeholder="Enter the course Code"></td>
								<td><input type="number" name="course_unit_9" placeholder="Enter the course unit"></td>
								<td><input type="text" name="course_grade_9" placeholder="Enter the course grade"></td>
							</tr>
							<tr class="datarow">
								<td class="sn">10</td>
								<td><input type="text" name="course_code_10" placeholder="Enter the course Code"></td>
								<td><input type="number" name="course_unit_10" placeholder="Enter the course unit"></td>
								<td><input type="text" name="course_grade_10" placeholder="Enter the course grade"></td>
							</tr>
							<tr class="breakrow">
								<td>CLICK ME TO LOAD INPUT</td><td></td><td></td><td></td>
							</tr>
							<tr class="datarow">
								<td class="sn">11</td>
								<td><input type="text" name="course_code_11" placeholder="Enter the course Code"></td>
								<td><input type="number" name="course_unit_11" placeholder="Enter the course unit"></td>
								<td><input type="text" name="course_grade_11" placeholder="Enter the course grade"></td>
							</tr>
							<tr class="datarow">
								<td class="sn">12</td>
								<td><input type="text" name="course_code_12" placeholder="Enter the course Code"></td>
								<td><input type="number" name="course_unit_12" placeholder="Enter the course unit"></td>
								<td><input type="text" name="course_grade_12" placeholder="Enter the course grade"></td>
							</tr>
							<tr class="datarow">
								<td class="sn">13</td>
								<td><input type="text" name="course_code_13" placeholder="Enter the course Code"></td>
								<td><input type="number" name="course_unit_13" placeholder="Enter the course unit"></td>
								<td><input type="text" name="course_grade_13" placeholder="Enter the course grade"></td>
							</tr>
							<tr class="datarow">
								<td class="sn">14</td>
								<td><input type="text" name="course_code_14" placeholder="Enter the course Code"></td>
								<td><input type="number" name="course_unit_14" placeholder="Enter the course unit"></td>
								<td><input type="text" name="course_grade_14" placeholder="Enter the course grade"></td>
							</tr>
							<tr class="datarow">
								<td class="sn">15</td>
								<td><input type="text" name="course_code_15" placeholder="Enter the course Code"></td>
								<td><input type="number" name="course_unit_15" placeholder="Enter the course unit"></td>
								<td><input type="text" name="course_grade_15" placeholder="Enter the course grade"></td>
							</tr>
							<tr class="breakrow">
								<td>CLICK ME TO LOAD INPUT</td><td></td><td></td><td></td>
							</tr>
							<tr class="datarow">
								<td class="sn">16</td>
								<td><input type="text" name="course_code_16" placeholder="Enter the course Code"></td>
								<td><input type="number" name="course_unit_16" placeholder="Enter the course unit"></td>
								<td><input type="text" name="course_grade_16" placeholder="Enter the course grade"></td>
							</tr>
							<tr class="datarow">
								<td class="sn">17</td>
								<td><input type="text" name="course_code_17" placeholder="Enter the course Code"></td>
								<td><input type="number" name="course_unit_17" placeholder="Enter the course unit"></td>
								<td><input type="text" name="course_grade_17" placeholder="Enter the course grade"></td>
							</tr>
							<tr class="datarow">
								<td class="sn">18</td>
								<td><input type="text" name="course_code_18" placeholder="Enter the course Code"></td>
								<td><input type="number" name="course_unit_18" placeholder="Enter the course unit"></td>
								<td><input type="text" name="course_grade_18" placeholder="Enter the course grade"></td>
							</tr>
							<tr class="datarow">
								<td class="sn">19</td>
								<td><input type="text" name="course_code_19" placeholder="Enter the course Code"></td>
								<td><input type="number" name="course_unit_19" placeholder="Enter the course unit"></td>
								<td><input type="text" name="course_grade_19" placeholder="Enter the course grade"></td>
							</tr>
							<tr class="datarow">
								<td class="sn">20</td>
								<td><input type="text" name="course_code_20" placeholder="Enter the course Code"></td>
								<td><input type="number" name="course_unit_20" placeholder="Enter the course unit"></td>
								<td><input type="text" name="course_grade_20" placeholder="Enter the course grade"></td>
							</tr>
						</tbody>
						<tr>
							<td colspan="4" style="text-align: center; width: 100%; background: green;">
								<input type="submit" name="btn" value="Calculate" style=" width: 100%; height: 50px; font-size: 25px; font-family: Apple-Chancery" class="btn btn-success form-control">
							</td>
						</tr>
					</form>
				</table>
			</center>
		</div>